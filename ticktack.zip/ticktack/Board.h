#ifndef BOARD_H
#define BOARD_H

#include <iostream>
using namespace std;

class Board {
private:
    char grid[3][3];
    int filledCells;

public:
    Board();

    void drawBoard() const;
    bool isValidMove(int row, int col) const;
    void makeMove(int row, int col, char symbol);
    bool checkWin(char symbol) const;
    bool isFull() const;
    int getFilledCellsCount() const;
};

#endif
