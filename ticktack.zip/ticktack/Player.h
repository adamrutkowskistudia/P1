#ifndef PLAYER_H
#define PLAYER_H

#include <string>
using namespace std;

class Player {
private:
    char symbol;
    string name;

public:
    Player(char sym = 'X', string n = "Player X");

    char getSymbol() const;
    string getName() const;
};

#endif
