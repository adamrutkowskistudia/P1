#include "TicTacToe.h"
#include <iostream>
using namespace std;

TicTacToe::TicTacToe() : currentPlayerIndex(0) {
    players[0] = Player('X', "Player X");
    players[1] = Player('O', "Player O");
}

Player& TicTacToe::getCurrentPlayer() {
    return players[currentPlayerIndex];
}

void TicTacToe::switchTurn() {
    currentPlayerIndex = (currentPlayerIndex + 1) % 2;
}

void TicTacToe::play() {
    int row, col;
    cout << "Welcome to Tic-Tac-Toe!" << endl;

    while (!board.isFull()) {
        board.drawBoard();

        Player& currentPlayer = getCurrentPlayer();

        while (true) {
            cout << currentPlayer.getName() << " (" << currentPlayer.getSymbol() << "), enter row (1-3) and column (1-3): ";
            cin >> row >> col;
            row--; col--;

            if (board.isValidMove(row, col)) break;
            cout << "Invalid move. Try again." << endl;
        }

        board.makeMove(row, col, currentPlayer.getSymbol());

        if (board.checkWin(currentPlayer.getSymbol())) {
            board.drawBoard();
            cout << currentPlayer.getName() << " wins!" << endl;
            return;
        }

        switchTurn();
    }

    board.drawBoard();
    cout << "It's a draw!" << endl;
}
