#include "Player.h"

Player::Player(char sym, string n) : symbol(sym), name(n) {}

char Player::getSymbol() const {
    return symbol;
}

string Player::getName() const {
    return name;
}
