#include "SnakeGame.h"

int main() {
    SnakeGame gra;
    gra.Run();
    return 0;
}
