#include "SnakeGame.h"

SnakeGame::SnakeGame() {
    srand(time(NULL));
    hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    Start();
}

void SnakeGame::Start() {
    gameover = false;
    kierunekWeza = STOP;
    HeadX = width / 2;
    HeadY = height / 2;
    Fx = rand() % width;
    Fy = rand() % height;
    wynik = 0;
    OgonD = 0;
}

void SnakeGame::Rysowanie() {
    system("cls");
    SetConsoleTextAttribute(hConsole, CYJAN);
    for (int i = 0; i < width + 3; i++) cout << "*";
    cout << endl;

    for (int i = 0; i < height; i++) {
        for (int j = 0; j <= width; j++) {
            SetConsoleTextAttribute(hConsole, CYJAN);
            if (j == 0) cout << "*";
            SetConsoleTextAttribute(hConsole, SZARY);

            if (i == HeadY && j == HeadX) {
                SetConsoleTextAttribute(hConsole, ZIELONY);
                cout << "$";
                SetConsoleTextAttribute(hConsole, SZARY);
            }
            else if (i == Fy && j == Fx) {
                SetConsoleTextAttribute(hConsole, CZERWONY);
                cout << "o";
                SetConsoleTextAttribute(hConsole, SZARY);
            }
            else {
                bool print = false;
                SetConsoleTextAttribute(hConsole, ZIELONY);
                for (int k = 0; k < OgonD; k++) {
                    if (OgonX[k] == j && OgonY[k] == i) {
                        cout << "s";
                        print = true;
                    }
                }
                SetConsoleTextAttribute(hConsole, SZARY);
                if (!print) cout << ".";
            }

            SetConsoleTextAttribute(hConsole, CYJAN);
            if (j == width) cout << "*";
            SetConsoleTextAttribute(hConsole, SZARY);
        }
        cout << endl;
    }

    SetConsoleTextAttribute(hConsole, CYJAN);
    for (int i = 0; i < width + 3; i++) cout << "*";
    SetConsoleTextAttribute(hConsole, SZARY);
    cout << endl;

    SetConsoleTextAttribute(hConsole, NIEBIESKI);
    cout << "Wynik: " << wynik << endl;
    SetConsoleTextAttribute(hConsole, SZARY);
}

void SnakeGame::Input() {
    if (_kbhit()) {
        switch (_getch()) {
            case KEY_LEFT: kierunekWeza = LEFT; break;
            case KEY_RIGHT: kierunekWeza = RIGHT; break;
            case KEY_UP: kierunekWeza = UP; break;
            case KEY_DOWN: kierunekWeza = DOWN; break;
            case 'q': gameover = true; break;
        }
    }
}

void SnakeGame::Logika() {
    for (int i = OgonD; i > 0; i--) {
        OgonX[i] = OgonX[i - 1];
        OgonY[i] = OgonY[i - 1];
    }

    if (OgonD > 0) {
        OgonX[0] = HeadX;
        OgonY[0] = HeadY;
    }

    switch (kierunekWeza) {
        case UP: HeadY--; break;
        case DOWN: HeadY++; break;
        case LEFT: HeadX--; break;
        case RIGHT: HeadX++; break;
        default: break;
    }

    if (HeadX > width || HeadY > height || HeadX < 0 || HeadY < 0)
        gameover = true;

    for (int i = 0; i < OgonD; i++) {
        if (OgonX[i] == HeadX && OgonY[i] == HeadY)
            gameover = true;
    }

    if (HeadX == Fx && HeadY == Fy) {
        wynik++;
        Fx = rand() % width;
        Fy = rand() % height;
        OgonD++;
    }
}

void SnakeGame::Run() {
    while (!gameover) {
        Rysowanie();
        Input();
        Logika();

        if (kierunekWeza == UP || kierunekWeza == DOWN)
            Sleep(25);
    }
}
