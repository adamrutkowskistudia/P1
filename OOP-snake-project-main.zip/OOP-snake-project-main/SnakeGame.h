#ifndef SNAKEGAME_H
#define SNAKEGAME_H

#include <windows.h>
#include <iostream>
#include <conio.h>
#include <time.h>

#define KEY_UP 72
#define KEY_DOWN 80
#define KEY_LEFT 75
#define KEY_RIGHT 77

#define CYJAN 11
#define CZERWONY 12
#define ZIELONY 10
#define NIEBIESKI 9
#define SZARY 7

using namespace std;


enum Kierunek { STOP = 0, UP, DOWN, LEFT, RIGHT };

class SnakeGame {
private:
    const int width = 40;
    const int height = 8;

    bool gameover;
    Kierunek kierunekWeza;

    int HeadX, HeadY;
    int Fx, Fy;
    int wynik;
    int OgonX[500], OgonY[500];
    int OgonD;

    HANDLE hConsole;

public:
    SnakeGame();     
    void Start();    
    void Rysowanie(); 
    void Input();     
    void Logika();  
    void Run();       
};

#endif
